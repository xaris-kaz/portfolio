#include "bench.h"
#include <pthread.h> //gia na mporoume na xrhsimopoihsoume thn bibliothikh pthread

pthread_mutex_t time_lock = PTHREAD_MUTEX_INITIALIZER;
double total_cost;

typedef struct { //struct pou krataei ta orismata twn synartisewn pou kaloun taq nhmata 
	long int count;
	int r;
} Func_args;

void _random_key(char *key,int length) {
	int i;
	char salt[36]= "abcdefghijklmnopqrstuvwxyz0123456789";

	for (i = 0; i < length; i++)
		key[i] = salt[rand() % 36];
}

void _print_header(int count)
{
	double index_size = (double)((double)(KSIZE + 8 + 1) * count) / 1048576.0;
	double data_size = (double)((double)(VSIZE + 4) * count) / 1048576.0;

	printf("Keys:\t\t%d bytes each\n", 
			KSIZE);
	printf("Values: \t%d bytes each\n", 
			VSIZE);
	printf("Entries:\t%d\n", 
			count);
	printf("IndexSize:\t%.1f MB (estimated)\n",
			index_size);
	printf("DataSize:\t%.1f MB (estimated)\n",
			data_size);

	printf(LINE1);
}

void print_stats(long int count, int t_count, int type) //typonei ta statistika 
{
	switch(type){
		case 1:
			printf("|Random-Write (done:%ld): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",count,(double)((total_cost/t_count) / count),(double)(count / (total_cost/t_count)),(total_cost/t_count));
			break;//diairoume to total_cost me t_count gia na paroume ton swsto xrono ektelesis se oles tis periptwseis
		case 2:
			printf("|Random-Read (done:%ld): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",count,(double)((total_cost/t_count) / count),(double)(count / (total_cost/t_count)),(total_cost/t_count));
			break;
		case 3:
			printf("|Random-Operations (done:%ld): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",count,(double)((total_cost/t_count) / count),(double)(count / (total_cost/t_count)),(total_cost/t_count));
			break;
	}
}			


void _print_environment()
{
	time_t now = time(NULL);

	printf("Date:\t\t%s", 
			(char*)ctime(&now));

	int num_cpus = 0;
	char cpu_type[256] = {0};
	char cache_size[256] = {0};

	FILE* cpuinfo = fopen("/proc/cpuinfo", "r");
	if (cpuinfo) {
		char line[1024] = {0};
		while (fgets(line, sizeof(line), cpuinfo) != NULL) {
			const char* sep = strchr(line, ':');
			if (sep == NULL || strlen(sep) < 10)
				continue;

			char key[1024] = {0};
			char val[1024] = {0};
			strncpy(key, line, sep-1-line);
			strncpy(val, sep+1, strlen(sep)-1);
			if (strcmp("model name", key) == 0) {
				num_cpus++;
				strcpy(cpu_type, val);
			}
			else if (strcmp("cache size", key) == 0)
				strncpy(cache_size, val + 1, strlen(val) - 1);	
		}

		fclose(cpuinfo);
		printf("CPU:\t\t%d * %s", 
				num_cpus, 
				cpu_type);

		printf("CPUCache:\t%s\n", 
				cache_size);
	}
}

void *write_op(void *arg) //h synarthsh poy tha ektelesei to put
{
	Func_args *f = (Func_args*) arg;
	long long start,end;
	double cost;
	start = get_ustime_sec();
	_write_test(f->count, f->r);
	end = get_ustime_sec();
	cost = end - start;
	pthread_mutex_lock(&time_lock);
	total_cost+=cost;
	pthread_mutex_unlock(&time_lock);
	return 0;
}

void *read_op(void *arg) //h synarthsh poy tha ektelesei to get
{
	Func_args *f = (Func_args*) arg;
	long long start,end;
	double cost;
	start = get_ustime_sec();
	_read_test(f->count, f->r);
	end = get_ustime_sec();
	cost = end - start;
	pthread_mutex_lock(&time_lock);
	total_cost+=cost;
	pthread_mutex_unlock(&time_lock);
	return 0;
}



int main(int argc,char** argv)
{
	long int count;
	int t_count; //arithmos nymatwn

	
	if (argc < 4) { //exoume 3 command line arguments pleon gia na pairnoume kai ton arithmo nhmatwn apo to terminal
		fprintf(stderr,"Usage: db-bench <write | read> <count> <number of threads>\n");
		exit(1);
	}
	open_db(); //anoigoume mia fora thn bash 
	if (strcmp(argv[1], "write") == 0) {
		int r = 0;

		count = atoi(argv[2]);
		t_count = atoi(argv[3]);
		if (t_count < 1)
		{
			t_count = 1;
		}
		pthread_t *threads = (pthread_t*)malloc(t_count*sizeof(pthread_t)); //pinakas me ta threads
		Func_args *fa = (Func_args*)malloc(t_count*sizeof(Func_args)); //pinakas me ta orismata gia kathe thread

		int quotient = count / t_count;
		int remainder = count % t_count;

		if (argc == 5) //egine apo 4 5 logw tou epipleon argument poy balame 
			r = 1;

		for(int i=0; i<t_count; i++) //arxikopoihsh twn timwn twn parametrwn to synarthsewn pou tha ektelesei to kathe nhma 
		{
			if(i==t_count-1) //xwrizoume isoposa thn douleia metaksei twn nhmatwn omws 
			{		//stin periptwsh pou h diaiserh exei ypoloipo 
				fa[i].count=quotient+remainder; //to teleutaio nhma pairnei thn epipleon douleia
				fa[i].r = r;
			}else{
				fa[i].count=quotient;
				fa[i].r = r;
			}
		}

		_print_header(count);
		_print_environment();

		for(int i=0; i<t_count; i++) //arxikopoihsh twn nhmatwn
		{
			pthread_create(&threads[i], NULL, write_op, (void *) &fa[i]);
		}

		for(int i=0; i<t_count; i++) //apodesmeush twn nhmatwn 
		{
			pthread_join(threads[i], NULL);
		}

		print_stats(count, t_count, 1); // emfanish statistikwn
		//_write_test(count, r);
	} else if (strcmp(argv[1], "read") == 0) {
		int r = 0;

		count = atoi(argv[2]);
		t_count = atoi(argv[3]);
		if (t_count < 1)
		{
			t_count = 1;
		}
		pthread_t *threads = (pthread_t*)malloc(t_count*sizeof(pthread_t)); //pinakas me ta threads
		Func_args *fa = (Func_args*)malloc(t_count*sizeof(Func_args)); //pinakas me ta orismata gia kathe thread

		int quotient = count / t_count;
		int remainder = count % t_count;

		if (argc == 5) //egine apo 4 5 logw tou epipleon argument poy balame 
			r = 1;

		for(int i=0; i<t_count; i++) //arxikopoihsh twn timwn twn parametrwn to synarthsewn pou tha ektelesei to kathe nhma 
		{
			if(i==t_count-1) //xwrizoume isoposa thn douleia metaksei twn nhmatwn omws 
			{		//stin periptwsh pou h diaiserh exei ypoloipo 
				fa[i].count=quotient+remainder; //to teleutaio nhma pairnei thn epipleon douleia
				fa[i].r = r;
			}else{
				fa[i].count=quotient;
				fa[i].r = r;
			}
		}

		_print_header(count);
		_print_environment();

		for(int i=0; i<t_count; i++) //arxikopoihsh twn nhmatwn
		{
			pthread_create(&threads[i], NULL, read_op, (void *) &fa[i]);
		}

		for(int i=0; i<t_count; i++) //apodesmeush twn nhmatwn 
		{
			pthread_join(threads[i], NULL);
		}

		print_stats(count, t_count, 2); // emfanish statistikwn
		//_read_test(count, r);
	}else if (strcmp(argv[1], "mixedop") == 0) {//eisagoume mia trith periptwsh me mixh read kai write
		
		int r = 0;		
		if (argc<5)
		{
			fprintf(stderr,"Usage: db-bench <write | read> <count> <number of threads> <reader percentage>\n");
			exit(1);				
		}
		
		count = atoi(argv[2]);
		t_count = atoi(argv[3]);
		if (t_count < 1)
		{
			t_count = 1;
		}
		int reader_percentage = atoi(argv[4]); //pososto twn nhmatwn pou einai readers		
		int readers = (t_count * reader_percentage) / 100; //upologismos tou arithmou twn readers 
		//int writters = t_count - readers; //upologismos tou arithmou twn writters
		
		pthread_t *threads = (pthread_t*)malloc(t_count*sizeof(pthread_t)); //pinakas me ta threads
		Func_args *fa = (Func_args*)malloc(t_count*sizeof(Func_args)); //pinakas me ta orismata gia kathe thread

		int quotient = count / t_count;
		int remainder = count % t_count;

		if (argc == 6) //egine apo 5 6 pou htan stis 2 prwtes periptwseis logw tou epipleon argument gia to pososto 
			r = 1;

		for(int i=0; i<t_count; i++) //arxikopoihsh twn timwn twn parametrwn to synarthsewn pou tha ektelesei to kathe nhma 
		{
			if(i==t_count-1) //xwrizoume isoposa thn douleia metaksei twn nhmatwn omws 
			{		//stin periptwsh pou h diaiserh exei ypoloipo 
				fa[i].count=quotient+remainder; //to teleutaio nhma pairnei thn epipleon douleia
				fa[i].r = r;
			}else{
				fa[i].count=quotient;
				fa[i].r = r;
			}
		}

		_print_header(count);
		_print_environment();

		for(int i=0; i<readers; i++) //arxikopoihsh twn nhmatwn
		{
			pthread_create(&threads[i], NULL, read_op, (void *) &fa[i]);
		}
		for(int i=readers; i<t_count; i++) //arxikopoihsh twn nhmatwn
		{
			pthread_create(&threads[i], NULL, write_op, (void *) &fa[i]);
		}
		for(int i=0; i<t_count; i++) //apodesmeush twn nhmatwn 
		{
			pthread_join(threads[i], NULL);
		}

		print_stats(count, t_count, 3); // emfanish statistikwn
	} else {
		fprintf(stderr,"Usage: db-bench <write | read> <count> <random>\n");
		exit(1);
	}
	close_db(); //kai afou oloklhrwsoume thn douleia mas thn kleinoume 
	return 1;
}
