package metadata;

public class MetadataManagerFactory 
{
	
	public NaiveFileMetadataManager createMetadataManager()
	{
		return new NaiveFileMetadataManager();
	}
}
