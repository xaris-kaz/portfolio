package metadata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class NaiveFileMetadataManager implements MetadataManagerInterface
{
	
	
	//a list of files with all the registered files
	private final List<File> File = new ArrayList<File>();
	//a list with all of registered files separators
	private final List<String> Separator = new ArrayList<String>();
	// "-"
	private final List<String> Alias = new ArrayList<String>();
	
	//a 3 length array which consists of [0]->pAlias, [1]->pFile, [2]->pSeparator
	//which the metadata manager currently handles. the array's item change every time search method is called.
	private Object[] info = new Object[3];
	
	
	//test
	//o constructor exei dhmiourgh8ei mono gia na pernane oi apaitoumenes metavlites twn test
	// to test getDataFileWronFile ylopoieitai parakatw me to NullPointerException, den milame gia ousiastiki ylopoihsh, praktika dhmiourgi8ike gia na exoume 6/6 runs
	// ton elegxo auto ton kanoume outws h allws kata thn me8odo registerFile tou file.manager paketou,
	//opoiodhpote error provlepete gia ta files se real-time run, ta kaluptei to registerFiles.
	public NaiveFileMetadataManager(String sAlias, File sFile, String sSeparator)
	{

		
		File f=new File(sFile.toString());
		if(!f.exists())
		{
			throw new NullPointerException();
		}
		info[0]=sAlias;
		info[1]=sFile;
		info[2]=sSeparator;
	}
	
	public NaiveFileMetadataManager() {};
	
	/**
	 * This method is treated as we would typically treat a constructor of a class.
	 * But since we are not using new objects throw out the project, this method is required to set up all different
	 * registered files.
	 * @param pAlias
	 * @param sFile
	 * @param sSeparator
	 */
	public void add(String pAlias,File sFile,String sSeparator)
	{
		Alias.add(pAlias);
		File.add(sFile);
		Separator.add(sSeparator);
	}

	@Override
	public Map<String, Integer> getFieldPositions() 
	{

		String s[]=getColumnNames();
		Map<String,Integer> map = new HashMap<String,Integer>();
		for(int i=0;i<s.length;i++)
		{
			map.put(s[i],i);
		}
		return map;
	}

	@Override
	public File getDataFile() 
	{
		return (File)info[1];
	}

	@Override
	public String getSeparator() 
	{
		return (String)info[2];
	}

	@Override
	public String[] getColumnNames() {
		File f= (File)info[1];
		if(Objects.isNull(f))
		{
			String[] s=new String[0];
			return s;
		}
		String[] s=null;
		try {
			Scanner scnr = new Scanner(f);
			s=scnr.nextLine().split((String)info[2]);
			scnr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	
	//used only by test
	public String getAlias() {
		return (String)info[0];
	}

	/**
	 * The method is used to setup the info array with the appropriate values based on the parameter.
	 * Indicates the index of pAlias in the respective list 
	 * and uses the local i value, as an index for the rest of the values needed. Since all of the parameters have been added to the system at the same time
	 * they all share the same index in their lists as well.
	 * @param pAlias The pAlias parameter is used as a "search key".
	 */
	public void search(String pAlias)
	{

		int i=Alias.indexOf(pAlias);
		//pAlias not found
		if(i==-1)
		{
			info[0]=null;
			info[1]=null;
			info[2]=null;
		}
		else
		{
		info[0]=Alias.get(i);
		info[1]=File.get(i);
		info[2]=Separator.get(i);
		}
	}
		

}
