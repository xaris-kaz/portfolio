package test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.Test;

import file.manager.StructuredFileManager;
import file.manager.StructuredFileManagerFactory;
import file.manager.StructuredFileManagerInterface;
import metadata.NaiveFileMetadataManager;

public class StructuredFileManagerTest {
	

	private static StructuredFileManagerInterface filemanager= (new StructuredFileManagerFactory()).createStructuredFileManager();
	
	
	//the logic behind this test is that the user can register multiple files, then choose whichever he prefers to proceed.
	//we will use  getMeta method to get to a result and getDataFile() to compare.
	//this test shows the functionality of the back-end when it comes to processing multiple files.
	@Test
	public void registerMultipleFilesHappyDay() throws NullPointerException, IOException
	{
		File covid = new File("./test/resources/input/CovidData.csv");
		File simple = new File("./test/resources/input/simple.csv");
		
		filemanager.registerFile("covid","./test/resources/input/CovidData.csv",",");
		filemanager.registerFile("simple","./test/resources/input/simple.csv",",");
		
		NaiveFileMetadataManager meta = ((StructuredFileManager)filemanager).getMeta("covid");
		assert(covid.equals(meta.getDataFile()));
		meta=((StructuredFileManager)filemanager).getMeta("simple");
		assert(simple.equals(meta.getDataFile()));
		
		
		
	}
	
	//same logic
	//tests over the functionality of the back-end processing different files at user's command.
	@Test
	public void getColumnNamesMultipleFilesHappyDay() throws NullPointerException, IOException
	{

		
		filemanager.registerFile("covid","./test/resources/input/CovidData.csv",",");
		filemanager.registerFile("simple","./test/resources/input/simple.csv",",");
		
		String[] expectedColNamesCovid = {"DATE:dateRep", "DAY:day", "MONTH:month", "YEAR:year", 
				"MSR:cases", "MSR:deaths", "GEO:countriesAndTerritories", "GEO:geoId", "GEO:countryterritoryCode", "POPULATIONpopData2020", "GEO:continentExp"};
	

		String[] expectedColNamesSimple = {"HF:Financing scheme","HC:Function","HP:Provider","LOCATION:Country","TIME:Year","MSR:Value"};
		
		
		
		String[] resColNamesCovid = filemanager.getFileColumnNames("covid");
		for (int i =0; i< resColNamesCovid.length;i++) {
			if (!resColNamesCovid[i].equals(expectedColNamesCovid[i]))
				fail("Erroneous col name arrays");
		}	
		String[] resColNamesSimple = filemanager.getFileColumnNames("simple");
		for (int j =0; j< resColNamesSimple.length;j++) {
		
			if (!resColNamesSimple[j].equals(expectedColNamesSimple[j]))
				
				fail("Erroneous col name arrays");
		}
		
		
		
	}
	
	

	

}
