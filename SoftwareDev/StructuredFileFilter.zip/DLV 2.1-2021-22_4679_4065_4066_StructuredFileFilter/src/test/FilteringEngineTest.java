package test;

import metadata.*;
import filtering.*;


import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class FilteringEngineTest {

	@Test
	public void setupFilteringEngineIncompatibleColNames()
	{
		//handling "simple.csv"
		NaiveFileMetadataManager meta = new NaiveFileMetadataManager("simple",new File("./test/resources/input/simple.csv"),",");
		
		//applying filters for the "covid.csv"
		Map<String,List<String>> atomicFilters = new HashMap<String, List<String>>();
		List<String> dateFilter = new ArrayList<String>();
		dateFilter.add("9");
		atomicFilters.put("MONTH:month", dateFilter);
		
		FilteringEngine fe = new FilteringEngine(atomicFilters,meta);
		assert(-1==fe.setupFilteringEngine(atomicFilters, meta));
	}

}
