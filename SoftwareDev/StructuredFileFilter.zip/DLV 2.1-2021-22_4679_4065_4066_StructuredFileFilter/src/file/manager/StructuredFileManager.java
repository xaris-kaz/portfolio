package file.manager;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import filtering.FilteringEngine;
import filtering.FilteringEngineFactory;
import metadata.NaiveFileMetadataManager;
import metadata.MetadataManagerFactory;
public class StructuredFileManager implements StructuredFileManagerInterface {

	
	private NaiveFileMetadataManager meta_m=(new MetadataManagerFactory()).createMetadataManager();
	private FilteringEngine filtering_m=(new FilteringEngineFactory()).createFilteringEngine();
	
	
	@Override
	public File registerFile(String pAlias, String pPath, String pSeparator) throws IOException, NullPointerException
	{		
		File file;
		try
		{
			file = File.createTempFile(pPath,".txt");			
			
			file = new File(pPath);
			if(!file.exists())
			{
				Scanner input=new Scanner(System.in);
				System.out.println("path specified is not valid.(file not found). Enter a valid one:");
				return registerFile(pAlias,input.nextLine(),pSeparator);
			}
			
			meta_m.add(pAlias, file, pSeparator);
			return file;
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public String[] getFileColumnNames(String pAlias)
	{				
		meta_m.search(pAlias);		
		return meta_m.getColumnNames();
	}

	@Override
	public List<String[]> filterStructuredFile(String pAlias, Map<String, List<String>> pAtomicFilters)
	{
	
		meta_m.search(pAlias);
		if(filtering_m.setupFilteringEngine(pAtomicFilters, meta_m)==0)
		{
			return filtering_m.workWithFile();
		}
		else
		{
			return null;
		}
	
	}

	@Override
	public int printResultsToPrintStream(List<String[]> recordList, PrintStream pOut) {
		int numRec=0;
		for(int i=0;i<recordList.size();i++)
		{
			
			for(int j=0;j<recordList.get(i).length;j++)
			{
				pOut.append(recordList.get(i)[j]);								
			}
			
			pOut.append("\n");
			numRec++;
			
		}
		return numRec;
	}

	/**
	 * this method is used only by tests.
	 * @param pAlias
	 * @return a metadatamanager object
	 */
	public NaiveFileMetadataManager getMeta(String pAlias) {
		// TODO Auto-generated method stub
		meta_m.search(pAlias);
		return meta_m;
	}

}
