package application.naive.client;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class client {

	
	
	
	public static void main(String args[])
	{
		NaiveApplicationController nac = new NaiveApplicationController();
		Scanner input=new Scanner(System.in);
		int counter=0;
		while(true)
		{
		
		System.out.println("Do you want to register a file to the system?(yes/no)");
		String ans1=input.nextLine().strip().trim();
		if(counter==0 && !ans1.equals("yes"))
		{
			System.out.println("There are 0 files registered at the time, you can not procceed unless you register at least one");
			while(!ans1.equals("yes"))
			{
				System.out.println("Please enter(yes) to proceed");
				ans1=input.nextLine().strip().trim();
			}
		}
		
		//file registration
		while(ans1.equals("yes"))
		{
		System.out.println("Enter a friendly name for your file:");
		String pAlias=input.nextLine().strip().trim();
		System.out.println("Enter file's path:");
		String pPath=input.nextLine().strip().trim();
		System.out.println("Enter file's separator:");
		String pSeparator=input.nextLine().strip().trim();
		File f=	nac.registerFile(pAlias, pPath, pSeparator);
		System.out.println("file: "+f+" registered!");
		System.out.println("Do you want to register an other file?(yes/no):");
		ans1=input.nextLine().strip().trim();
		}
		
		
		
		System.out.println("Enter the field's name you wish to apply filters on");
		String field=input.nextLine().strip().trim();		
		Map<String,List<String>> pAtomicFilters = new HashMap<String,List<String>>();
		List<String> filters=new ArrayList<String>();
	
		
		String ans2="yes";	
		//user's filters 
		while(ans2.equals("yes"))
		{
			System.out.println("Enter a filter for the "+field+" field:");
			filters.add(input.nextLine().strip().trim());
			
			System.out.println("Do you want to add an other filter?(yes/no)");
			ans2=input.nextLine().strip().trim();
		}		
		pAtomicFilters.put(field, filters);
	
		//asking for more filters, for another field
		System.out.println("Do you want to add more filters for an other field?(yes/no)");		
		String ans3=input.nextLine().strip().trim();	
		List<String> filters2;
		
		//asks for the new field name(ans3), puts as many filters as user wants(ans3a), loops all over again if user wants to add new filters for an other field.
		while(ans3.equals("yes"))
		{
			filters2=new ArrayList<String>();
			System.out.println("Enter field's name:");
			field=input.nextLine().strip().trim();
			
			String ans3a="yes";
			while(ans3a.equals("yes"))
			{
				System.out.println("Enter a filter you wish to apply on "+field+" field:");
				filters2.add(input.nextLine().strip().trim());
				System.out.println("Do you want to add an other filter?(yes/no)");
				ans3a=input.nextLine().strip().trim();
			}
			
			pAtomicFilters.put(field,filters2);
			System.out.println("Do you want to add more filters for another field?(yes/no)");
			ans3=input.nextLine().strip().trim();
		}
		
		
		//applying the filters user just entered, to whichever file he has registered to the system.
		//User's file option is not limited over the file he just registered.
		System.out.println("Enter the file's alias you want to apply the filters on:");
		String alias=input.nextLine().strip().trim();
		System.out.println("Enter the output file's name:");
		String outputFileName=input.nextLine().strip().trim();
		
	
		List<String[]> result=nac.executeFilterAndShowJTable(alias, pAtomicFilters, outputFileName);
		
		//save file's results to outputStream
		System.out.println("Do you want to save the result to a file?(yes/no)");
		String ans4=input.nextLine().strip().trim();
		if(ans4.equals("yes"))
		{
			System.out.println("Enter an output file name:");
			String output=input.nextLine().strip().trim();
			nac.saveToResultTextFile(output, result);
		}
		
		
		
		//chart setup
		System.out.println("Enter a xAxis name:");
		String xAxis=input.nextLine().strip().trim();
		System.out.println("Enter a yAxis name: ");
		String yAxis=input.nextLine().strip().trim();
		
		
		
		//chart creation cases
		System.out.println("Do you want to create a bar chart or a line chart?(bar/line)");
		String ans5=input.nextLine().strip().trim().toLowerCase();
		//case barChart
		if(ans5.equals("bar"))
		{
			System.out.println("Enter file's alias:");
			String palias=input.nextLine().strip().trim();
			System.out.println("Enter an output file name: ");
			String poutput=input.nextLine().strip().trim();
			nac.showSingleSeriesBarChart(palias, result, xAxis, yAxis, poutput);
		}
		//case lineChart
		else if(ans5.equals("line"))
		{
			System.out.println("Enter file's alias:");
			String palias=input.nextLine().strip().trim();
			System.out.println("Enter an output file name: ");
			String poutput=input.nextLine().strip().trim();
			nac.showSingleSeriesLineChart(palias, result, xAxis, yAxis, poutput);
		}
		
		
		
		
		
		
		//loops all over again
		System.out.println("Continue running?(yes/no)");
		if(input.nextLine().strip().trim().equals("yes"))
		{
			counter++;
			continue;
		}
		else
		{
			break;
		}
		
		
		
		}
	
		input.close();
	}
}
