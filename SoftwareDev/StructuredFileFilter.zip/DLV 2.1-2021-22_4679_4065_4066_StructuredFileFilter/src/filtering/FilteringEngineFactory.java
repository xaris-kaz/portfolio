package filtering;

public class FilteringEngineFactory {

	public FilteringEngine createFilteringEngine() 
	{
		return new FilteringEngine();
	}

}
