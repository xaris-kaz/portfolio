package filtering;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

import metadata.MetadataManagerInterface;
import metadata.NaiveFileMetadataManager;

public class FilteringEngine implements FilteringEngineInterface 
{
	
	private MetadataManagerInterface meta_m;
	private Map<String,List<String>> filters;
	private File f;
	private Map<String,Integer> fieldPositions= new HashMap<String,Integer>();
	private String[] columnNames; 
	
	
	/**
	 * Only used by tests.
	 * @param atomicFilters
	 * @param metadataManager
	 */
	public FilteringEngine(Map<String, List<String>> atomicFilters, NaiveFileMetadataManager metadataManager)
	{
		meta_m=metadataManager;
		filters=atomicFilters;
		 fieldPositions=meta_m.getFieldPositions();
	}
	
	//main constructor. In the whole project we never user more than one object of our classes.
	//so there is never the need of creating a new object, since we handle multiple registered files at once.
	public FilteringEngine()
	{}

	@Override
	public int setupFilteringEngine(Map<String, List<String>> pAtomicFilters,MetadataManagerInterface pMetadataManager) 
	{
		meta_m=pMetadataManager;
		
		 f=pMetadataManager.getDataFile();
		 columnNames =pMetadataManager.getColumnNames();
		 if(Objects.isNull(f))
		 {
			return -1; 
		 }
		 
		 for(Map.Entry<String,List<String>> entry: pAtomicFilters.entrySet())
		 {
			 if(Objects.isNull(entry.getKey()) || Objects.isNull(entry.getValue()))
			 {
				 return -1;
			 }
		 }
		 
		 //case that field name of the atomic filters is not the same as the column Names of the file
		 boolean b=false;
		 for(Map.Entry<String,List<String>> entry:pAtomicFilters.entrySet())
		 {
			 String s = (String)entry.getKey();
			 for(int i=0;i<columnNames.length;i++)
			 {	
				 
				 if(s.equals(columnNames[i])) {
				 b=true;
				 break;
				 }
			 }
			 
		 }

		 if(b==false)
		 {	
			 System.out.println("Found an incompatible field name during setup");
			 return -1;
		}
		 filters=pAtomicFilters;
		 fieldPositions=meta_m.getFieldPositions();
		 f=meta_m.getDataFile();
		 return 0;
	}

	@Override
	public List<String[]> workWithFile() 
	{
		
		List<String[]> reg = new ArrayList<String[]>();
		f=meta_m.getDataFile();
		try {
			
			Scanner input = new Scanner(f);
			input.nextLine();
			while(input.hasNext())
			{
				reg.add(input.nextLine().split(meta_m.getSeparator()));
			}
			input.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();

		}
		
	
				
		for(Map.Entry<String,List<String>> entry: filters.entrySet())
		{
			List<String[]> temp = new ArrayList<String[]>();
		
			String field = (String)entry.getKey();
			int pos = fieldPositions.get(field);
			List<String> f =entry.getValue();
			
			for(int i=0;i<reg.size();i++)
			{
				String[] l = reg.get(i);
		
				
				for(int j=0;j<f.size();j++)
				{
				
					if(l[pos].equals(f.get(j)))
					{
					
						temp.add(reg.get(i));
					}
				}
				
			}
			
			//deep copy
			reg.clear();
			for(int i=0;i<temp.size();i++)
			{
				reg.add(temp.get(i));
			}
			
		}
		
	
		return reg;
	}

}
