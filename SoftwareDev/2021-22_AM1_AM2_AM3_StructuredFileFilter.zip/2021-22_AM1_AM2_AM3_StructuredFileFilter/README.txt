EXAMPLE

Assume that the project is being carried out by two students
Mitsos Mitsopoulos with AM 4567
Kitsos Kitsopoulos with AM 4678

Todo
1. Rename the entire project to 4567_4678_StructuredFileFilter
   (such that we know which submitted project pertains to which team)
2. Populate the current file with the respective content that the spec says, e.g.,:

********************************************
Names
Mitsos Mitsopoulos with AM 4567
Kitsos Kitsopoulos with AM 4678

Req's
No extra libraries are needed
********************************************
