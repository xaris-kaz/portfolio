package com.service;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.dao.ProfessorDAO;
import com.dao.SubjectDAO;
import com.dao.ThesisDAO;
import com.model.Application;
import com.model.Professor;
import com.model.Subject;
import com.model.Thesis;

import java.util.*;
@ExtendWith(SpringExtension.class)
@SpringBootTest
class ProfessorServiceImplTest {
	
	@Autowired
	private ProfessorService professorService;
	
	@MockBean
	private ProfessorDAO professorDAO;
	
	@MockBean
	private ThesisDAO thesisDAO;
	
	@MockBean
	private SubjectDAO subjectDAO;
	
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		List<Professor> professors = new ArrayList<Professor>();
		Professor professor = new Professor("username");
		Professor professor2 = new Professor("username2");
		professors.add(professor);
		professors.add(professor2);
		
		Subject subject = new Subject(1, "title1", professor);
		Subject subject2 = new Subject(2, "title2", professor);
		
		professor.addSubject(subject);
		professor.addSubject(subject2);
		
		Application application1 = new Application(1, 8, 8, 1);
		Application application2 = new Application(2, 7, 9, 2);
		application1.setSubject(subject);
		application2.setSubject(subject);
		
		subject.addApplication(application1);
		subject.addApplication(application2);
		

		Thesis thesis = new Thesis(1, 7, 8, 9);
		thesis.setProfessor(professor);
		professor.addThesis(thesis);
		
		Mockito.when(professorDAO.findAll()).thenReturn(professors);
		Mockito.when(professorDAO.save(professor)).thenReturn(professor);

		Mockito.when(subjectDAO.getById(1)).thenReturn(subject);
	}

	@Test
	void testRetrieveProfile() {
		Professor professor = professorService.retrieveProfile("username");
		assertEquals("username", professor.getUser_name());
	}

	@Test
	void testSaveProfile() {
		Professor professor3 = new Professor("username2");
		professorService.saveProfile(professor3);
		Professor professor = professorService.retrieveProfile("username2");
		assertEquals("username2", professor.getUser_name());
	}

	@Test
	void testListProfessorSubjects() {
		List<Subject> subjects = professorService.listProfessorSubjects("username");
		assertEquals(2, subjects.size());
	}

	@Test
	void testAddSubject() {
		Professor professor = new Professor("username");
		Subject subject = new Subject(43, "title3", professor);
		professorService.addSubject("username", subject);

		List<Subject> subjects = professorService.listProfessorSubjects("username");
		assertEquals(3, subjects.size());
		
	}

	@Test
	void testListApplications() {
		List<Application> applications = professorService.listApplications("username", 1);
		assertEquals(2, applications.size());
	}

	@Test
	void testListProfessorTheses() {
		List<Thesis> theses = professorService.listProfessorTheses("username");
		assertEquals(1, theses.size());
	}

	@Test
	void testAssignSubject() {
		professorService.assignSubject("BestAvgGradeStrategy", 1);
		List<Thesis> theses = professorService.listProfessorTheses("username");
		assertEquals(2, theses.size());
		assertEquals(8, theses.get(1).getStudent().getCurrentAverageGrade());
	}

	@Test
	void testAssignSubject2() {
		professorService.assignSubject("FewestCoursesStrategy", 1);
		List<Thesis> theses = professorService.listProfessorTheses("username");
		assertEquals(2, theses.size());
		assertEquals(8, theses.get(1).getStudent().getRemainingCourses());
	}
}
