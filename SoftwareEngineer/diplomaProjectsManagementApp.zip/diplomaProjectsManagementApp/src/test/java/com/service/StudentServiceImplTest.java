package com.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.dao.StudentDAO;
import com.model.*;

import java.util.*;
@ExtendWith(SpringExtension.class)
@SpringBootTest
class StudentServiceImplTest {

	@Autowired
	private StudentService studentService;
	
	@MockBean
	private StudentDAO studentDAO;
	
	@BeforeEach
	void setUp() throws Exception {
		Student student = new Student("username");
		Student student2 = new Student("username2");
		
		List<Student> students = new ArrayList<Student>();
		students.add(student);
		students.add(student2);
		
		Mockito.when(studentDAO.findAll()).thenReturn(students);
	}

	@Test
	void testRetrieveProfile() {
		Student student = studentService.retrieveProfile("username");
		assertEquals("username", student.getUser_name());
	}

}
