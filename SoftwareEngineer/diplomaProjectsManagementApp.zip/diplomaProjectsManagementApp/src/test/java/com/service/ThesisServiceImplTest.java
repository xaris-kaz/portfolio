package com.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.dao.ThesisDAO;
import com.model.Application;
import com.model.Professor;
import com.model.Subject;
import com.model.Thesis;

class ThesisServiceImplTest {

	@Autowired
	private ThesisService thesisService;
	
	@MockBean
	private ThesisDAO thesisDAO;
	
	private List<Subject> subjects;
	
	@BeforeEach
	void setUp() throws Exception {
		List<Professor> professors = new ArrayList<Professor>();
		Professor professor = new Professor("username");
		Professor professor2 = new Professor("username2");
		professors.add(professor);
		professors.add(professor2);
		
		Subject subject = new Subject(1, "title1", professor);
		Subject subject2 = new Subject(2, "title2", professor);
		
		professor.addSubject(subject);
		professor.addSubject(subject2);
		

		Thesis thesis = new Thesis(1, 7, 8, 9);
		thesis.setSubject(subject);
		thesis.setProfessor(professor);
		professor.addThesis(thesis);
		
		List<Thesis> theses = new ArrayList<Thesis>();
		subjects = new ArrayList<Subject>();
		theses.add(thesis);
		subjects.add(subject);
		subjects.add(subject2);
		
		Mockito.when(thesisDAO.findAll()).thenReturn(theses);
	}

	@Test
	void testAvailableSubjects() {
		List<Subject> available = thesisService.availableSubjects(subjects);
		assertEquals(1, available.size());
	}

}
