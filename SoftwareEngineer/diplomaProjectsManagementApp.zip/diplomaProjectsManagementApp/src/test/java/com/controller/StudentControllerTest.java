package com.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.model.Application;
import com.model.Professor;
import com.model.Subject;
import com.model.Thesis;
import com.model.Student;
import com.service.ApplicationService;
import com.service.StudentService;
import com.service.SubjectService;
import com.service.ThesisService;
import com.service.UserService;

@WebMvcTest(StudentController.class)
@WithMockUser(value = "spring")
@AutoConfigureMockMvc(addFilters = false)
class StudentControllerTest {
	
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private StudentService studentService;
	@MockBean
	private UserService userService;
	@MockBean
	private SubjectService subjectService;
	@MockBean
	private ThesisService thesisService;
	@MockBean
	private ApplicationService applicationService;
	
	@BeforeEach
	void setUp() throws Exception {
		Professor professor = new Professor("username");
		Student student = new Student("username");
		Subject subject = new Subject(1, "title1", professor);
		Subject subject2 = new Subject(2, "title2", professor);
		
		professor.addSubject(subject);
		professor.addSubject(subject2);
		

		ArrayList<Subject> subjects = new ArrayList<Subject>();
		subjects.add(subject);
		Mockito.when(studentService.retrieveProfile("spring")).thenReturn(student);
		Mockito.when(thesisService.availableSubjects(subjects)).thenReturn(subjects);
		Mockito.when(subjectService.findById(1)).thenReturn(subject);
		Mockito.when(subjectService.findAll()).thenReturn(subjects);
	}
	
	@Test
	void testGetStudentMainMenu() {
		
		try {
			this.mockMvc
				.perform(get("/stud/dashboard"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Show subject list")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testRetrieveProfile() {
		try {
			this.mockMvc
				.perform(post("/stud/changeInfo"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Change info")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("student"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	@Test
	void testSaveProfile() {
		try {
			Student student = new Student("username");
			student.setFullName("test");
			student.setRemainingCourses(1);
			student.setYearOfStudies(5);
			student.setCurrentAverageGrade(8);
			
			this.mockMvc
				.perform(post("/stud/save").flashAttr("student", student))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Change info")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}


	@Test
	void testListProfessorSubjects() {
		try {
			this.mockMvc
				.perform(post("/stud/showSubjectList"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of available subjects")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subjects"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void testShowInfoSubject() {
		try {
			this.mockMvc
				.perform(post("/stud/infoSubject/{id}", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Apply")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void testApplySubject() {
		try {
			this.mockMvc
				.perform(post("/stud/apply/{id}", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of available subjects")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subjects"));;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
