package com.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.model.Application;
import com.model.Professor;
import com.model.Subject;
import com.model.Thesis;
import com.service.ProfessorService;
import com.service.SubjectService;
import com.service.ThesisService;
import com.service.UserService;

@WebMvcTest(ProfessorController.class)
@WithMockUser(value = "spring")
@AutoConfigureMockMvc(addFilters = false)
class ProfessorControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private ProfessorService professorService;
	@MockBean
	private UserService userService;
	@MockBean
	private SubjectService subjectService;
	@MockBean
	private ThesisService thesisService;
	
	@BeforeEach
	void setUp() throws Exception {
		List<Professor> professors = new ArrayList<Professor>();
		Professor professor = new Professor("username");
		Professor professor2 = new Professor("username2");
		professors.add(professor);
		professors.add(professor2);
		
		Subject subject = new Subject(1, "title1", professor);
		Subject subject2 = new Subject(2, "title2", professor);
		
		professor.addSubject(subject);
		professor.addSubject(subject2);
		
		Application application1 = new Application(1, 8, 8, 1);
		Application application2 = new Application(2, 7, 9, 2);
		application1.setSubject(subject);
		application2.setSubject(subject);
		
		subject.addApplication(application1);
		subject.addApplication(application2);
		

		Thesis thesis = new Thesis(1, 7, 8, 9);
		thesis.setProfessor(professor);
		professor.addThesis(thesis);
		ArrayList<Subject> subjects = new ArrayList<Subject>();
		subjects.add(subject);
		Mockito.when(professorService.retrieveProfile("spring")).thenReturn(professor);
		Mockito.when(thesisService.availableSubjects(subjects)).thenReturn(subjects);
		Mockito.when(thesisService.availableSubjects(subjects)).thenReturn(subjects);
		Mockito.when(subjectService.findById(1)).thenReturn(subject);
		Mockito.when(thesisService.findById(1)).thenReturn(thesis);
	}

	@Test
	void testGetProfessorMainMenu() {

		try {
			this.mockMvc
				.perform(get("/prof/dashboard"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Show assigned list")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testRetrieveProfile() {

		try {
			this.mockMvc
				.perform(post("/prof/changeInfo"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Change info")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("professor"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testSaveProfile() {
		try {
			Professor professor = professorService.retrieveProfile("spring");
			professor.setFullName("test");
			professor.setSpecialty("test");
			
			this.mockMvc
				.perform(get("/prof/save").flashAttr("professor", professor))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Show assigned list")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testListProfessorSubjects() {
		try {
			Professor professor = professorService.retrieveProfile("spring");
			professor.setFullName("test");
			professor.setSpecialty("test");
			
			this.mockMvc
				.perform(get("/prof/showSubjectList"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of available subjects")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subjects"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void testShowSubjectForm() {
		try {
			this.mockMvc
				.perform(get("/prof/addSubject"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Add")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testAddSubject() {
		try {
			Subject subject = new Subject("title", "objectives");
			this.mockMvc
				.perform(get("/prof/saveSubject").flashAttr("subject", subject))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Subject saved")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
			subject.setTitle("");
			this.mockMvc
			.perform(get("/prof/saveSubject").flashAttr("subject", subject))
			.andDo(print())
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("Give title or objectives")))
			.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testListApplications() {
		try {
			this.mockMvc
				.perform(get("/prof/applicationSubject/{id}", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Subject applications")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	
	@Test
	void testAssignSubjectIntModel() {
		try {
			this.mockMvc
				.perform(get("/prof/assignSubject/{id}", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Assignent list")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subject"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testAssignSubjectStringIntModel() {
		try {
			this.mockMvc
				.perform(get("/prof/assignSubject/{type}/{id}", "FewestCoursesStrategy", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of available subjects")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("subjects"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testListProfessorThesis() {
		try {
			this.mockMvc
				.perform(get("/prof/showAssignedList"))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of assigned theses")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("theses"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGradeThesis() {
		try {
			this.mockMvc
				.perform(get("/prof/gradeThesis/{id}", 1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("Set grades")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("thesis"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testSaveGrades() {
		try {
			Thesis thesis = new Thesis(1, 7, 8, 9);
			this.mockMvc
				.perform(get("/prof/saveGrades").flashAttr("thesis", thesis))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(content().string(containsString("List of assigned theses")))
				.andExpect(MockMvcResultMatchers.model().attributeExists("theses"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	void testCalculateTotalThesis() {
		try {
			this.mockMvc
			.perform(get("/prof/calculateTotal/{id}", 1))
			.andDo(print())
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("List of assigned theses")))
			.andExpect(MockMvcResultMatchers.model().attributeExists("theses"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
