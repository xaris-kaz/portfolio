package com.model.strategies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.model.Application;
import com.model.Student;

import java.util.*;

class FewestCoursesStrategyTest {
	private BestApplicantStrategy strategy;
	private Application application1;
	private Application application2;
	
	@BeforeEach
	void setUp() throws Exception {
		strategy = BestApplicantStrategyFactory.createStrategy("FewestCoursesStrategy");
		application1 = new Application(1, 8, 8, 1);
		application2 = new Application(2, 7, 9, 2);
	}

	@Test
	void testCompareApplications() {
		FewestCoursesStrategy strategy1 = (FewestCoursesStrategy)strategy;
		int cmp = strategy1.compareApplications(application1, application2);
		assertEquals(-1, cmp);
		
		cmp = strategy1.compareApplications(application2, application1);
		assertEquals(1, cmp);
		
		cmp = strategy1.compareApplications(application2, application2);
		assertEquals(0, cmp);
	}

	@Test
	void testFindBestApplicant() {
		List<Application> applications = new ArrayList<Application>();
		applications.add(application1);
		applications.add(application2);
		
		Student student = strategy.findBestApplicant(applications);
		
		assertEquals(1, student.getId());
	}

}
