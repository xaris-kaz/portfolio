package com.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StudentTest {
	private Student student;
	private List<Application> applications;
	private Subject subject;
	private Subject subject2;
	
	@BeforeEach
	void setUp() throws Exception {
		student = new Student();
		subject = new Subject(1);
		subject2 = new Subject(2);
		applications = new ArrayList<Application>();
		Application application = new Application(subject);
		applications.add(application);
		student.setApplications(applications);
	}

	@Test
	void testHasApplication() {
		assertEquals(false, student.hasApplication(subject2));
		assertEquals(true, student.hasApplication(subject));
	}

	@Test
	void testCheckFields() {
		student = new Student(1, 11, -1);
		student.setFullName("");
		assertEquals(student.checkFields(), false);
		
		student.setFullName("sdf");
		assertEquals(student.checkFields(), false);
		
		student.setCurrentAverageGrade(4);
		assertEquals(student.checkFields(), false);

		student.setCurrentAverageGrade(6);
		assertEquals(student.checkFields(), false);

		student.setYearOfStudies(6);
		assertEquals(student.checkFields(), false);
		
		student.setRemainingCourses(6);
		assertEquals(student.checkFields(), true);
		
	}

}
