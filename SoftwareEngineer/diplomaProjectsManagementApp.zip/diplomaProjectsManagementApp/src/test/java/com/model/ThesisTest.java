package com.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
@SpringBootTest
class ThesisTest {
	private Thesis thesis;
	private Thesis thesis2;
	@BeforeEach
	void setUp() throws Exception {
		thesis2 = new Thesis(1, 7, 8, 9);
		thesis = new Thesis(1, 4, 4, 4);
		
	}

	@Test
	void testCheckFields() {
		assertEquals(false, thesis.checkFields());
		thesis.setImplementationGrade(7);
		assertEquals(false, thesis.checkFields());
		thesis.setPresentationGrade(8);
		assertEquals(false, thesis.checkFields());
		thesis.setReportGrade(9);
		assertEquals(true, thesis.checkFields());
	}

	@Test
	void testCalculateTotal() {
		thesis2.calculateTotal();
		assertEquals(7.45, thesis2.getTotalGrade(), 0.01);
	}

}
