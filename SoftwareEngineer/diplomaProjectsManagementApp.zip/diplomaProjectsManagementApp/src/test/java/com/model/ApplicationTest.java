package com.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ApplicationTest {
	private Application application1;
	private Application application2;
	
	@BeforeEach
	void setUp() throws Exception {
		application1 = new Application(1, 8, 8, 1);
		application2 = new Application(2, 7, 9, 2);
	}

	@Test
	void testCompareFewestCourses() {
		int cmp = application1.compareFewestCourses(application2);
		assertEquals(-1, cmp);
		
		cmp = application2.compareFewestCourses(application1);
		assertEquals(1, cmp);
		
		cmp = application1.compareFewestCourses(application1);
		assertEquals(0, cmp);
	}

	@Test
	void testCompareBestAvgGrade() {
		int cmp = application1.compareBestAvgGrade(application2);
		assertEquals(-1, cmp);
		
		cmp = application2.compareBestAvgGrade(application1);
		assertEquals(1, cmp);
		
		cmp = application1.compareBestAvgGrade(application1);
		assertEquals(0, cmp);
	}

}
