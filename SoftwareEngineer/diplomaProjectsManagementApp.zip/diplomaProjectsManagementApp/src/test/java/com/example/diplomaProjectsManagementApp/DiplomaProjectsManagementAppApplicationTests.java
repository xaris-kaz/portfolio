package com.example.diplomaProjectsManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomaProjectsManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
