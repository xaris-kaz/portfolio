package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Professor;

public interface ProfessorDAO extends JpaRepository<Professor, Integer>{

}
