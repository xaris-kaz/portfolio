package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Thesis;

public interface ThesisDAO extends JpaRepository<Thesis, Integer> {

}
