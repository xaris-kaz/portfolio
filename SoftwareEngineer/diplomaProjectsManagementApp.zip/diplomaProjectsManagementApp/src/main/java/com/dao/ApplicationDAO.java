package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Application;

public interface ApplicationDAO extends JpaRepository<Application, Integer>{

}
