package com.model;

import java.util.List;
import java.util.ArrayList;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="subjects")
public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	
	@Column(name="title")
	private String title;
	
	@Column(name="objectives")
	private String objectives;
	
	@OneToOne(mappedBy="subject")
	private Thesis thesis;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "professor_id")
	private Professor professor;
	
	@OneToMany(fetch = FetchType.LAZY,mappedBy="subject",cascade = CascadeType.ALL)
	private List<Application> applications;

	
	public Subject(int id, String title, Professor professor) {
		super();
		this.id = id;
		this.title = title;
		this.professor = professor;
		this.applications = new ArrayList<Application>();
	}
	public Subject(String title, String objectives) {
		this.title = title;
		this.objectives = objectives;
	}
	public Subject(int id) {
		// TODO Auto-generated constructor stub
		this.id = id;
	}
	public Subject() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getObjectives() {
		return objectives;
	}

	public void setObjectives(String objectives) {
		this.objectives = objectives;
	}

	public Thesis getThesis() {
		return thesis;
	}

	public void setThesis(Thesis thesis) {
		this.thesis = thesis;
	}

	public List<Application> getApplications() {
		return applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public void addApplication(Application application) {
		applications.add(application);
	}
	
}
