package com.model.strategies;

import java.util.List;

import com.model.Application;
import com.model.Student;

public class BestAvgGradeStrategy extends TemplateStrategyAlgorithm {

	@Override
	protected int compareApplications(Application application1, Application application2) {
		// TODO Auto-generated method stub
		return application1.compareBestAvgGrade(application2);
	}


}
