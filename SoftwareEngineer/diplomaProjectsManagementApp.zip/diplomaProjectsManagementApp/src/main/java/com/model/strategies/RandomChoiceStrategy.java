package com.model.strategies;

import com.model.Application;
import java.util.Random;

public class RandomChoiceStrategy extends TemplateStrategyAlgorithm {
	private Random rn = new Random();
	@Override
	protected int compareApplications(Application application1, Application application2) {
		// TODO Auto-generated method stub
		double r = rn.nextDouble() - 0.5;
		if(r < 0)
			return -1;
		else if(r > 0)
			return 1;
		return 0;
	}

}
