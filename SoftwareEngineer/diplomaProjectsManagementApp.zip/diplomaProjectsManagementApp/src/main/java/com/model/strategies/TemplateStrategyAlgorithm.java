package com.model.strategies;

import java.util.List;

import com.model.Application;
import com.model.Student;

public abstract class TemplateStrategyAlgorithm implements BestApplicantStrategy{

	@Override
	public Student findBestApplicant(List<Application> applications) {
		// TODO Auto-generated method stub
		Application bestApplication = applications.get(0);
		for(int i = 1; i < applications.size(); i++) {
			if(compareApplications(applications.get(i), bestApplication) < 0)
				bestApplication = applications.get(i);
		}
		Student bestApplicant = bestApplication.getStudent();
		return bestApplicant;
	}
	
	protected abstract int compareApplications(Application application1, Application application2);
}
