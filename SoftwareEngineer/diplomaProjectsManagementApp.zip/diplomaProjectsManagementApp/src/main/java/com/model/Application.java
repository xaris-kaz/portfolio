package com.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="applications")
public class Application {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "student_id")
	private Student student;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "subject_id")
	private Subject subject;
	
	public Application() {
		
	}
	public Application(int id, float currentAverageGrade, int remainingCourses, int studentId) {
		this.id = id;
		this.student = new Student(studentId, currentAverageGrade, remainingCourses);
	}

	public Application(Subject subject) {
		// TODO Auto-generated constructor stub
		this.subject = subject;
	}
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public int compareFewestCourses(Application application2) {
		// TODO Auto-generated method stub
		Student student2 = application2.getStudent();
		return student.getRemainingCourses() - student2.getRemainingCourses();
	}

	public int compareBestAvgGrade(Application application2) {
		// TODO Auto-generated method stub

		Student student2 = application2.getStudent();
		double dif = student.getCurrentAverageGrade() - student2.getCurrentAverageGrade();
		
		if(dif < 0)
			return 1;
		else if(dif > 0)
			return -1;
		return 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	
	
	
}
