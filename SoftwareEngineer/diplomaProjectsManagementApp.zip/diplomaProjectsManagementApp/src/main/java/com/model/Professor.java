package com.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="professors")
public class Professor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="full_name")
	private String fullName;
	
	@Column(name="specialty")
	private String specialty;
	
	@Column(name="user_name")
	private String user_name;
	
	@OneToMany(fetch = FetchType.LAZY,mappedBy="professor",cascade = CascadeType.ALL)
	private List<Thesis> theses;
	
	@OneToMany(fetch = FetchType.LAZY,mappedBy="professor",cascade = CascadeType.ALL)
	private List<Subject> subjects;
	
	public Professor() {
		
	}	
	public Professor(String username) {
		// TODO Auto-generated constructor stub
		this.user_name = username;
		this.subjects = new ArrayList<Subject>();
		this.theses = new ArrayList<Thesis>();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getSpecialty() {
		return specialty;
	}
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	public List<Thesis> getTheses() {
		return theses;
	}
	public void setTheses(List<Thesis> theses) {
		this.theses = theses;
	}
	public List<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public void addSubject(Subject subject) {
		// TODO Auto-generated method stub
		subjects.add(subject);
	}
	public void addThesis(Thesis thesis) {
		// TODO Auto-generated method stub
		theses.add(thesis);
	}
	
}
