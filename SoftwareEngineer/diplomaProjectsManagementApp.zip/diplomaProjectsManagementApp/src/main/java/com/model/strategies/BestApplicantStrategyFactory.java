package com.model.strategies;

public class BestApplicantStrategyFactory {
	public static BestApplicantStrategy createStrategy(String type) {
		
		if(type.equals("BestAvgGradeStrategy"))
			return new BestAvgGradeStrategy();
		if(type.equals("FewestCoursesStrategy"))
			return new FewestCoursesStrategy();
		if(type.equals("RandomChoiceStrategy"))
			return new RandomChoiceStrategy();
		
		return null;
	}
}
