package com.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="thesis")
public class Thesis {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="implementation_grade")
	private double implementationGrade;
	
	@Column(name="report_grade")
	private double reportGrade;
	
	@Column(name="presentation_grade")
	private double presentationGrade;
	
	@Column(name="total_grade")
	private double totalGrade;
	
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name = "subject_id")
	private Subject subject;
	
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name = "student_id")
	private Student student;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "professor_id")
	private Professor professor;

	public Thesis() {
		
	}
	public Thesis(int id, double implementationGrade, double reportGrade, double presentationGrade) {
		super();
		this.id = id;
		this.implementationGrade = implementationGrade;
		this.reportGrade = reportGrade;
		this.presentationGrade = presentationGrade;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getImplementationGrade() {
		return implementationGrade;
	}

	public void setImplementationGrade(double implementationGrade) {
		this.implementationGrade = implementationGrade;
	}

	public double getReportGrade() {
		return reportGrade;
	}

	public void setReportGrade(double reportGrade) {
		this.reportGrade = reportGrade;
	}

	public double getPresentationGrade() {
		return presentationGrade;
	}

	public void setPresentationGrade(double presentationGrade) {
		this.presentationGrade = presentationGrade;
	}

	public double getTotalGrade() {
		return totalGrade;
	}

	public void setTotalGrade(double totalGrade) {
		this.totalGrade = totalGrade;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public boolean checkFields() {
		// TODO Auto-generated method stub
		if(implementationGrade < 5 || implementationGrade >  10)
			return false;
		if(presentationGrade < 5 || presentationGrade >  10)
			return false;
		if(reportGrade < 5 || reportGrade >  10)
			return false;
		
		return true;
	}

	public void calculateTotal() {
		// TODO Auto-generated method stub
		totalGrade = 0.7*implementationGrade + 0.15*presentationGrade + 0.15*reportGrade;
	}
	
	
}
