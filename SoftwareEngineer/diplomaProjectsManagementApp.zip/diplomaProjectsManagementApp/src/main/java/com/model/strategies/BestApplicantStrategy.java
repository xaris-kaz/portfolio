package com.model.strategies;

import java.util.List;

import com.model.Application;
import com.model.Student;

public interface BestApplicantStrategy {
	public Student findBestApplicant(List<Application> applications);
}
