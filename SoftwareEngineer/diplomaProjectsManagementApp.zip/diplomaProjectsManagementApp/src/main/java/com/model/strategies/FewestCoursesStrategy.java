package com.model.strategies;

import com.model.Application;

public class FewestCoursesStrategy extends TemplateStrategyAlgorithm {

	@Override
	protected int compareApplications(Application application1, Application application2) {
		// TODO Auto-generated method stub
		return application1.compareFewestCourses(application2);
	}

}
