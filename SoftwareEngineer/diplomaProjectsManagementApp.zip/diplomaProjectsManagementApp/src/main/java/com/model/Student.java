package com.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="students")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="full_name")
	private String fullName;
	
	
	@Column(name="year_of_studies")
	private int yearOfStudies;
	
	@Column(name="curent_average_grade")
	private double currentAverageGrade;
	
	@Column(name="remaining_courses")
	private int remainingCourses;
	
	@Column(name="user_name")
	private String user_name;
	
	@OneToMany(fetch = FetchType.LAZY,mappedBy="student",cascade = CascadeType.ALL)
	private List<Application> applications;
		
	public Student(String username) {
		// TODO Auto-generated constructor stub
		this.user_name = username;
		this.applications = new ArrayList<Application>();
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(int studentId, float currentAverageGrade, int remainingCourses) {
		// TODO Auto-generated constructor stub
		this.id = studentId;
		this.currentAverageGrade = currentAverageGrade;
		this.remainingCourses = remainingCourses;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getYearOfStudies() {
		return yearOfStudies;
	}

	public void setYearOfStudies(int yearOfStudies) {
		this.yearOfStudies = yearOfStudies;
	}

	public double getCurrentAverageGrade() {
		return currentAverageGrade;
	}

	public void setCurrentAverageGrade(double currentAverageGrade) {
		this.currentAverageGrade = currentAverageGrade;
	}

	public int getRemainingCourses() {
		return remainingCourses;
	}

	public void setRemainingCourses(int remainingCourses) {
		this.remainingCourses = remainingCourses;
	}

	public List<Application> getApplications() {
		return applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}

	public boolean hasApplication(Subject other) {
		// TODO Auto-generated method stub
		for(int i = 0; i < applications.size(); i++) {
			Subject subject = applications.get(i).getSubject();
			if(subject.getId() == other.getId()) {
				return true;
			}
		}
		return false;
	}

	public boolean checkFields() {
		// TODO Auto-generated method stub
		if(fullName.equals(""))
			return false;
		if(currentAverageGrade < 5 || currentAverageGrade > 10) 
			return false;
		if(yearOfStudies <= 4)
			return false;
		if(remainingCourses < 0 || remainingCourses > 47)
			return false;
		return true;
	}
	
}
