package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Professor;
import com.model.Student;
import com.model.Subject;
import com.model.Thesis;
import com.service.ProfessorService;
import com.service.SubjectService;
import com.service.ThesisService;
import com.service.UserService;

@Controller
public class ProfessorController {
	@Autowired
	ProfessorService professorService;
	@Autowired
	UserService userService;
	@Autowired
	SubjectService subjectService;
	@Autowired
	ThesisService thesisService;
	
	@RequestMapping("/prof/dashboard")
	public String getProfessorMainMenu() {
		return "prof/dashboard";
	}
	
	@RequestMapping("/prof/changeInfo")
	public String retrieveProfile(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
		
		Professor prof = professorService.retrieveProfile(username);
		model.addAttribute("professor", prof);
		return "prof/change";
	}
	
	@RequestMapping("/prof/save")
	public String saveProfile(@ModelAttribute("professor") Professor professor, Model model) {
		if(professor.getFullName().equals("") || professor.getSpecialty().equals("")) {
        	model.addAttribute("successMessage", "Give full name or specialty");
        	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

    		String username = authentication.getName();
        	Professor prof = professorService.retrieveProfile(username);
    		model.addAttribute("professor", prof);
            return "prof/change";
        }
		professorService.saveProfile(professor);
		return "prof/dashboard";
	}
	
	@RequestMapping("/prof/showSubjectList")
	public String listProfessorSubjects(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
    	Professor prof = professorService.retrieveProfile(username);
		List<Subject> subjects = prof.getSubjects();
		subjects = thesisService.availableSubjects(subjects);
		model.addAttribute("subjects", subjects);
		return "prof/subjectList";
	}
	
	@RequestMapping("/prof/addSubject")
	public String showSubjectForm(Model model) {
		Subject subject = new Subject();
		model.addAttribute("subject", subject);
		return "prof/addSubject";
	}
	@RequestMapping("/prof/saveSubject")
	public String addSubject(@ModelAttribute("subject") Subject subject, Model model) {
		
		if(subject.getTitle().equals("") || subject.getObjectives().equals("")) {
			model.addAttribute("successMessage", "Give title or objectives");
		}
		else {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	
			String username = authentication.getName();
	    	Professor prof = professorService.retrieveProfile(username);
	    	subject.setProfessor(prof);
	    	subjectService.saveSubject(subject);
	    	model.addAttribute("successMessage", "Subject saved");
		}
    	subject = new Subject();
		model.addAttribute("subject", subject);
		return "prof/addSubject";
	}
	

	
	@RequestMapping("/prof/applicationSubject/{id}")
	public String listApplications(@PathVariable("id")int id, Model model) {
		Subject subject = subjectService.findById(id);
		model.addAttribute("subject", subject);
		return "prof/applicationsList";
	}
	
	@RequestMapping("/prof/deleteSubject/{id}")
	public String deleteSubject(@PathVariable("id")int id, Model model) {
		Subject subject = subjectService.findById(id);
		subjectService.deleteSubject(id);
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
    	Professor prof = professorService.retrieveProfile(username);
		List<Subject> subjects = prof.getSubjects();
		subjects = thesisService.availableSubjects(subjects);
		model.addAttribute("subjects", subjects);
		return "prof/gradeThesis";
	}
	
	@RequestMapping("/prof/assignSubject/{id}")
	public String assignSubject(@PathVariable("id")int id, Model model) {
		Subject subject = subjectService.findById(id);
		model.addAttribute("subject", subject);
		return "prof/assignmentList";
	}

	@RequestMapping("/prof/assignSubject/{type}/{id}")
	public String assignSubject(@PathVariable("type")String type, @PathVariable("id")int id, Model model) {
		
		professorService.assignSubject(type, id);
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
    	Professor prof = professorService.retrieveProfile(username);
		List<Subject> subjects = prof.getSubjects();
		subjects = thesisService.availableSubjects(subjects);
		model.addAttribute("subjects", subjects);
		return "prof/subjectList";
	}
	@RequestMapping("/prof/showAssignedList")
	public String listProfessorThesis(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
    	List<Thesis> theses = professorService.listProfessorTheses(username);
		model.addAttribute("theses", theses);
		return "prof/thesesList";
	}
	
	@RequestMapping("/prof/gradeThesis/{id}")
	public String gradeThesis(@PathVariable("id")int id, Model model) {
		Thesis thesis = thesisService.findById(id);
		model.addAttribute("thesis", thesis);
		return "prof/gradeThesis";
	}
	
	@RequestMapping("/prof/saveGrades")
	public String saveGrades(@ModelAttribute("thesis") Thesis thesis, Model model) {
		
		if(thesis.checkFields() == false) {
			model.addAttribute("successMessage", "Give valid values for the fields");
			thesis = thesisService.findById(thesis.getId());
			model.addAttribute("thesis", thesis);
			return "prof/gradeThesis";
        }
		else {
			Thesis thesis2 = thesisService.findById(thesis.getId());
			thesis2.setImplementationGrade(thesis.getImplementationGrade());
			thesis2.setPresentationGrade(thesis.getPresentationGrade());
			thesis2.setReportGrade(thesis.getReportGrade());
			thesisService.saveThesis(thesis2);
			
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			String username = authentication.getName();
	    	List<Thesis> theses = professorService.listProfessorTheses(username);
			model.addAttribute("theses", theses);
			return "prof/thesesList";
		}
	}
	
	@RequestMapping("/prof/calculateTotal/{id}")
	public String calculateTotalThesis(@PathVariable("id")int id, Model model) {
		Thesis thesis = thesisService.findById(id);
		thesis.calculateTotal();
		model.addAttribute("thesis", thesis);
		
		thesisService.saveThesis(thesis);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
    	List<Thesis> theses = professorService.listProfessorTheses(username);
		model.addAttribute("theses", theses);
		return "prof/thesesList";
	}
	

	
}
