package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


import com.model.Subject;
import com.model.Student;
import com.model.Application;
import com.service.StudentService;
import com.service.SubjectService;
import com.service.ThesisService;
import com.service.UserService;
import com.service.ApplicationService;

@Controller
public class StudentController {
	@Autowired
	StudentService studentService;
	@Autowired
	UserService userService;
	@Autowired
	SubjectService subjectService;
	@Autowired
	ThesisService thesisService;
	@Autowired
	ApplicationService applicationService;
	
	@RequestMapping("/stud/dashboard")
	public String getStudentMainMenu() {
		return "stud/dashboard";
	}
	
	@RequestMapping("/stud/changeInfo")
	public String retrieveProfile(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		String username = authentication.getName();
		
		Student stud = studentService.retrieveProfile(username);
		model.addAttribute("student", stud);
		return "stud/change";
	}
	
	@RequestMapping("/stud/save")
	public String saveProfile(@ModelAttribute("student") Student student, Model model) {
		if(student.checkFields() == false) {
        	model.addAttribute("successMessage", "Give full name and valid values for the rest fields");
        	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    		String username = authentication.getName();
    		Student stud = studentService.retrieveProfile(username);
    		model.addAttribute("student", stud);
    		return "stud/change";
        }
		studentService.saveProfile(student);
		return "stud/dashboard";
	}
	
	@RequestMapping("/stud/showSubjectList")
	public String listProfessorSubjects(Model model) {
		
		List<Subject> subjects = subjectService.findAll();
		subjects = thesisService.availableSubjects(subjects);
		model.addAttribute("subjects", subjects);
		return "stud/subjectList";
	}
	
	@RequestMapping("/stud/infoSubject/{id}")
	public String showInfoSubject(@PathVariable("id")int id, Model model) {
		Subject subject = subjectService.findById(id);
		model.addAttribute("subject", subject);
		return "stud/subjectInfo";
	}
	
	@RequestMapping("/stud/apply/{id}")
	public String applySubject(@PathVariable("id")int id, Model model) {
		Subject subject = subjectService.findById(id);
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();
		Student stud = studentService.retrieveProfile(username);
		
		if(stud.hasApplication(subject) == true) {
			model.addAttribute("successMessage", "You have already applied for subject with title: " + subject.getTitle() + ". Please wait for assignment.");
		}
		else {
			Application app = new Application();
			app.setStudent(stud);
			app.setSubject(subject);
			applicationService.saveApplication(app);
			model.addAttribute("successMessage", "You have applied for subject with title: " + subject.getTitle());
		}
		
		
		List<Subject> subjects = subjectService.findAll();
		subjects = thesisService.availableSubjects(subjects);
		model.addAttribute("subjects", subjects);
		
		return "stud/subjectList";
		
	}
}
