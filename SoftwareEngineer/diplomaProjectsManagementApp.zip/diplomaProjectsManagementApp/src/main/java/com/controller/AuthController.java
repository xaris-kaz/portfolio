package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.User;
import com.model.Professor;
import com.model.Student;
import com.service.ProfessorService;
import com.service.StudentService;
import com.service.UserService;

@Controller
public class AuthController {
    @Autowired
    UserService userService;
    
    @Autowired
    ProfessorService professorService;
    
    @Autowired
    StudentService studentService;

    @RequestMapping("/login")
    public String login(){
        return "auth/signin";
    }

    @RequestMapping("/register")
    public String register(Model model){
        model.addAttribute("user", new User());
        return "auth/signup";
    }

    @RequestMapping("/save")
    public String registerUser(@ModelAttribute("user") User user, Model model){
       
        if(userService.isUserPresent(user)){
            model.addAttribute("successMessage", "User already registered!");
            return "auth/signin";
        }
        if(user.getUsername().equals("") || user.getPassword().equals("")) {
        	model.addAttribute("successMessage", "Give username or password");
            return "auth/signup";
        }
        userService.saveUser(user);
        String userType = user.getRole().getValue();
        if(userType.equals("Professor")) {
        	Professor professor = new Professor(user.getUsername());
        	professorService.saveProfile(professor);
        }
        else {
        	Student student = new Student(user.getUsername());
        	studentService.saveProfile(student);
        }
        model.addAttribute("successMessage", "User registered successfully!");

        return "auth/signin";
    }
}