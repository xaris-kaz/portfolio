package com.service;

import java.util.List;

import com.model.Subject;

public interface SubjectService {
	public void saveSubject(Subject subject);
	public List<Subject> findAll();
	public Subject findById(int id);
	public void deleteSubject(int id);
}
