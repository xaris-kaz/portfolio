package com.service;

import com.model.Student;

public interface StudentService {
	public void saveProfile(Student student);
	public Student retrieveProfile(String username);
}
