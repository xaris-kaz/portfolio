package com.service;

import java.util.List;

import com.model.Subject;
import com.model.Thesis;

public interface ThesisService {
	public void saveThesis(Thesis thesis);
	public List<Thesis> findAll();
	public List<Subject> availableSubjects(List<Subject> subjects);
	public Thesis findById(int id);
}
