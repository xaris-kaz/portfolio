package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.StudentDAO;
import com.model.Student;


@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentDAO studentDAO;
	
	@Override
	public void saveProfile(Student student) {
		// TODO Auto-generated method stub
		studentDAO.save(student);
	}

	@Override
	public Student retrieveProfile(String username) {
		// TODO Auto-generated method stub
		List<Student> allStudents = studentDAO.findAll();
		Student s = null;
		for(int i = 0; i < allStudents.size(); i++) {
			Student stud = allStudents.get(i);
			if(stud.getUser_name().equals(username)) {
				s = stud;
				break;
			}
		}
		return s;
	}
	
}
