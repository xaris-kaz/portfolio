package com.service;

import com.model.Application;

public interface ApplicationService {
	public void saveApplication(Application application);
}
