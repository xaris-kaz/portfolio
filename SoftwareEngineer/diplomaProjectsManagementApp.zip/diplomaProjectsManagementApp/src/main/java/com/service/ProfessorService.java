package com.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Application;
import com.model.Professor;
import com.model.Subject;
import com.model.Thesis;

@Service
public interface ProfessorService {
	public Professor retrieveProfile(String username);
	public void saveProfile(Professor professor);
	public List<Subject> listProfessorSubjects(String username);
	public void addSubject(String username, Subject subject);
	public List<Application> listApplications(String username, Integer id);
	public List<Thesis> listProfessorTheses(String username);
	public void assignSubject(String type, Integer id);
}
