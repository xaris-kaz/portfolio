package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ApplicationDAO;
import com.model.Application;

@Service
public class ApplicationServiceImpl implements ApplicationService{
	@Autowired
	ApplicationDAO applicationDAO;
	
	@Override
	public void saveApplication(Application application) {
		// TODO Auto-generated method stub
		applicationDAO.save(application);
	}

}
