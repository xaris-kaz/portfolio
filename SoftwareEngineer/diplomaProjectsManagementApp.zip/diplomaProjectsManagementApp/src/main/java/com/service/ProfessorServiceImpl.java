package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProfessorDAO;
import com.dao.ThesisDAO;
import com.dao.SubjectDAO;
import com.model.Application;
import com.model.Professor;
import com.model.Student;
import com.model.Subject;
import com.model.Thesis;
import com.model.strategies.BestApplicantStrategy;
import com.model.strategies.BestApplicantStrategyFactory;
@Service
public class ProfessorServiceImpl implements ProfessorService {
	@Autowired
	private ProfessorDAO professorDAO;
	
	@Autowired
	private ThesisDAO thesisDAO;
	
	@Autowired
	private SubjectDAO subjectDAO;
	
	@Override
	public Professor retrieveProfile(String username) {
		// TODO Auto-generated method stub
		List<Professor> allProfessors = professorDAO.findAll();
		Professor p = null;
		for(int i = 0; i < allProfessors.size(); i++) {
			Professor prof = allProfessors.get(i);
			if(prof.getUser_name().equals(username)) {
				p = prof;
				break;
			}
		}
		return p;
	}

	@Override
	public void saveProfile(Professor professor) {
		// TODO Auto-generated method stub
		professorDAO.save(professor);
	}

	@Override
	public List<Subject> listProfessorSubjects(String username) {
		// TODO Auto-generated method stub
		Professor p = retrieveProfile(username);
		if(p == null)
			return null;
		return p.getSubjects();
	}

	@Override
	public void addSubject(String username, Subject subject) {
		// TODO Auto-generated method stub
		Professor p = retrieveProfile(username);
		p.addSubject(subject);
		professorDAO.save(p);
	}

	@Override
	public List<Application> listApplications(String username, Integer id) {
		// TODO Auto-generated method stub
		List<Subject> allSubjects = listProfessorSubjects(username);
		Subject s = null;
		for(int i = 0; i < allSubjects.size(); i++) {
			Subject subj = allSubjects.get(i);
			if(subj.getId() == id) {
				s = subj;
				break;
			}
		}
		if(s == null)
			return null;
		return s.getApplications();
	}

	@Override
	public List<Thesis> listProfessorTheses(String username) {
		// TODO Auto-generated method stub
		Professor p = retrieveProfile(username);
		if(p == null)
			return null;
		return p.getTheses();
	}

	@Override
	public void assignSubject(String type, Integer id) {
		// TODO Auto-generated method stub
		
		Subject s = subjectDAO.getById(id);
		List<Application> applications = s.getApplications();
		
		
		BestApplicantStrategy strategy = BestApplicantStrategyFactory.createStrategy(type);
		Student student = strategy.findBestApplicant(applications);
		
		Professor prof = s.getProfessor();
		Thesis thesis = new Thesis();
		thesis.setSubject(s);
		thesis.setProfessor(prof);
		thesis.setStudent(student);
		prof.addThesis(thesis);
		thesisDAO.save(thesis);
	}

}
