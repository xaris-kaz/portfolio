package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ApplicationDAO;
import com.dao.SubjectDAO;
import com.model.Application;
import com.model.Subject;

@Service
public class SubjectServiceImpl implements SubjectService{

	@Autowired
	SubjectDAO subjectDAO;
	@Autowired
	ApplicationDAO applicationDAO;
	
	@Override
	public void saveSubject(Subject subject) {
		// TODO Auto-generated method stub
		subjectDAO.save(subject);
	}

	@Override
	public List<Subject> findAll() {
		// TODO Auto-generated method stub
		return subjectDAO.findAll();
	}

	@Override
	public Subject findById(int id) {
		// TODO Auto-generated method stub
		return subjectDAO.getById(id);
	}

	@Override
	public void deleteSubject(int id) {
		// TODO Auto-generated method stub
		Subject subject = subjectDAO.getById(id);
		List<Application> applications = subject.getApplications();
		for(int i = 0; i < applications.size(); i++) {
			applicationDAO.deleteById(applications.get(i).getId());
		}
		subjectDAO.deleteById(subject.getId());
	}

}
