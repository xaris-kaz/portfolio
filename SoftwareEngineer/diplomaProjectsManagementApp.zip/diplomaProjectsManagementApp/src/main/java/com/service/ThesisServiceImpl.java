package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ThesisDAO;
import com.model.Subject;
import com.model.Thesis;
@Service
public class ThesisServiceImpl implements ThesisService{
	@Autowired
	ThesisDAO thesisDAO;
	
	@Override
	public void saveThesis(Thesis thesis) {
		// TODO Auto-generated method stub
		thesisDAO.save(thesis);
	}

	@Override
	public List<Thesis> findAll() {
		// TODO Auto-generated method stub
		return thesisDAO.findAll();
	}

	@Override
	public List<Subject> availableSubjects(List<Subject> subjects) {
		// TODO Auto-generated method stub
		List<Thesis> theses = findAll();
		for(int i = 0; i < theses.size(); i++) {
			Subject subject = theses.get(i).getSubject();
			subjects.remove(subject);
		}
		return subjects;
	}

	@Override
	public Thesis findById(int id) {
		// TODO Auto-generated method stub
		return thesisDAO.getById(id);
	}

}
